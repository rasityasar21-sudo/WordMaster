package com.example.wordmaster

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import java.time.LocalDate
import java.util.Locale

data class Word(val english:String,val turkish:String,val pronunciation:String,val example:String,val translation:String,val level:String)
private fun loadWords(ctx:Context):List<Word> = try {
 val raw=ctx.assets.open("dictionary.json").bufferedReader(Charsets.UTF_8).use{it.readText()}
 val arr=JSONArray(raw); (0 until arr.length()).map { i -> val o=arr.getJSONObject(i); Word(o.getString("english"),o.getString("turkish"),o.getString("pronunciation"),o.getString("example"),o.getString("translation"),o.getString("level")) }
} catch (_:Exception) { emptyList() }

class MainActivity:ComponentActivity(){
 private var tts:TextToSpeech?=null
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); tts=TextToSpeech(this){s->if(s==TextToSpeech.SUCCESS)tts?.language=Locale.UK}; setContent { MaterialTheme { WordMasterApp { tts?.speak(it,TextToSpeech.QUEUE_FLUSH,null,"word") } } }}
 override fun onDestroy(){tts?.stop();tts?.shutdown();super.onDestroy()}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun WordMasterApp(speak:(String)->Unit){
 val ctx= LocalContext.current
 val prefs= remember { ctx.getSharedPreferences("wordmaster_progress",Context.MODE_PRIVATE) }
 val words= remember { loadWords(ctx) }
 var page by remember { mutableStateOf("Ana Sayfa") }
 var query by remember { mutableStateOf("") }; var filter by remember { mutableStateOf("Tümü") }; var index by remember { mutableIntStateOf(0) }
 var coins by remember { mutableIntStateOf(prefs.getInt("coins",0)) }; var xp by remember { mutableIntStateOf(prefs.getInt("xp",0)) }
 var level by remember { mutableStateOf(prefs.getString("level","A1") ?: "A1") }
 val learned= remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("learned",emptySet())?:emptySet()) } }
 val favs= remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("favs",emptySet())?:emptySet()) } }
 val unlocked= remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("unlocked",emptySet())?:emptySet()) } }
 var streak by remember { mutableIntStateOf(prefs.getInt("streak",0)) }
 var lastStudy by remember { mutableStateOf(prefs.getString("lastStudy","")?:"") }
 var quizIndex by remember { mutableIntStateOf(0) }; var quizCorrect by remember { mutableIntStateOf(0) }; var quizAnswered by remember { mutableIntStateOf(0) }; var selected by remember { mutableStateOf("") }; var feedback by remember { mutableStateOf("") }
 var notice by remember { mutableStateOf("") }
 fun save(){prefs.edit().putInt("coins",coins).putInt("xp",xp).putString("level",level).putStringSet("learned",learned.toSet()).putStringSet("favs",favs.toSet()).putStringSet("unlocked",unlocked.toSet()).putInt("streak",streak).putString("lastStudy",lastStudy).apply()}
 fun recordStudy(){val today=LocalDate.now().toString(); if(lastStudy!=today){if(lastStudy==LocalDate.now().minusDays(1).toString())streak++ else streak=1;lastStudy=today;if(streak>0 && streak%7==0){coins+=15;notice="7 günlük seri tamamlandı! +15 coin"}};save()}
 val visible=words.filter{(it.english.contains(query,true)||it.turkish.contains(query,true))&&(filter=="Tümü"||it.level==filter)}
 val quizPool=words.filter{it.level==level}.ifEmpty{words}; val current=quizPool[(quizIndex%quizPool.size.coerceAtLeast(1))]
 fun nextQuestion(){quizIndex++;selected="";feedback=""}
 Scaffold(topBar={TopAppBar(title={Text("WordMasterUltimate",fontWeight=FontWeight.Bold)},actions={Text("🪙 $coins",Modifier.padding(end=8.dp));Text("⭐ $xp",Modifier.padding(end=12.dp))})},bottomBar={NavigationBar{listOf("Ana Sayfa","Kelimeler","Quiz","Mağaza","Profil").forEach{p->NavigationBarItem(selected=page==p,onClick={page=p;notice=""},icon={Text(when(p){"Ana Sayfa"->"🏠";"Kelimeler"->"📚";"Quiz"->"🧠";"Mağaza"->"🛍️";else->"👤"})},label={Text(p)})}}}){pad->
 Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 if(notice.isNotBlank()){Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)){Text(notice,Modifier.padding(12.dp));TextButton(onClick={notice=""}){Text("Kapat")}}}
 when(page){
 "Ana Sayfa"->{Text("Merhaba! 👋",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("İnternetsiz kelime öğren, quiz çöz, coin biriktir.")
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){SmallStat("Seri","🔥 $streak gün",Modifier.weight(1f));SmallStat("Öğrenilen","${learned.size}",Modifier.weight(1f));SmallStat("Seviye",level,Modifier.weight(1f))}
 Button(onClick={page="Kelimeler"},modifier=Modifier.fillMaxWidth()){Text("Sözlüğe git")};Button(onClick={page="Quiz"},modifier=Modifier.fillMaxWidth()){Text("Quiz başlat")};Button(onClick={recordStudy();notice=if(notice.isBlank())"Bugünkü çalışma kaydedildi." else notice},modifier=Modifier.fillMaxWidth()){Text("Bugünkü çalışmayı kaydet")}
 Text("Sözlükte ${words.size} kayıt var. İlerleme: ${if(words.isEmpty())0 else learned.size*100/words.size}%");LinearProgressIndicator(progress={if(words.isEmpty())0f else (learned.size.toFloat()/words.size).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth())
 Text("Coin yalnızca seri ve görev başarılarından kazanılır; kelime öğrenmek coin vermez.",style=MaterialTheme.typography.bodySmall)
 }
 "Kelimeler"->{Text("Çevrimdışı sözlük",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("İnternet bağlantısı gerekmez.",style=MaterialTheme.typography.bodySmall)
 OutlinedTextField(query,{query=it;index=0},label={Text("İngilizce veya Türkçe ara")},modifier=Modifier.fillMaxWidth(),singleLine=true)
 Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("Tümü","A1","A2","B1","B2","C1").forEach{f->FilterChip(selected=filter==f,onClick={filter=f;index=0},label={Text(f)})}}
 if(visible.isEmpty())Text("Kelime bulunamadı.") else {val w=visible[index.coerceIn(0,visible.lastIndex)];Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(w.level,color=MaterialTheme.colorScheme.primary);Text(w.english,style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold);Text(w.turkish,style=MaterialTheme.typography.titleLarge);Text("Yaklaşık okunuş: ${w.pronunciation}");Text(w.example,fontWeight=FontWeight.Medium);Text(w.translation)
 Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={speak(w.english)}){Text("🔊 Dinle")};OutlinedButton(onClick={if(favs.contains(w.english))favs.remove(w.english) else favs.add(w.english);save()}){Text(if(favs.contains(w.english))"★ Favoride" else "☆ Favori")};OutlinedButton(onClick={if(learned.add(w.english)){xp+=2;recordStudy();save();notice="Kelime öğrenildi. +2 XP (coin verilmedi)."}else notice="Bu kelime zaten öğrenildi."}){Text(if(learned.contains(w.english))"✓ Öğrenildi" else "Biliyorum")}}
 }}
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){OutlinedButton(onClick={index=(index-1).coerceAtLeast(0)}){Text("Önceki")};Text("${index+1}/${visible.size}");Button(onClick={index=(index+1).coerceAtMost(visible.lastIndex)}){Text("Sonraki")}}
 }
 }
 "Quiz"->{Text("Kelime Quizi",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Seviye: $level • Soru ${quizIndex%10+1}/10");Text("'${current.english}' kelimesinin Türkçe karşılığı nedir?",style=MaterialTheme.typography.titleLarge)
 val options=remember(quizIndex,level){(listOf(current.turkish)+quizPool.filter{it.english!=current.english}.shuffled().take(3).map{it.turkish}).distinct().shuffled()}
 options.forEach{o->OutlinedButton(onClick={if(selected.isBlank()){selected=o;quizAnswered++;if(o==current.turkish){quizCorrect++;xp+=5;recordStudy();feedback="Doğru! +5 XP"}else feedback="Doğru cevap: ${current.turkish}";if(quizIndex%10==9){val score=quizCorrect;val key="quizReward_${level}_${LocalDate.now()}";if(score>=9&&!prefs.getBoolean(key,false)){coins+=5;prefs.edit().putBoolean(key,true).apply();feedback+="\n%90 başarı: +5 coin (bugün bu seviye için bir kez)"};feedback+="\nTest skoru: $score/10"};save()}},modifier=Modifier.fillMaxWidth(),enabled=selected.isBlank()){Text(o)}}
 if(feedback.isNotBlank()){Text(feedback);Button(onClick={if(quizIndex%10==9){quizCorrect=0;quizAnswered=0};nextQuestion()}){Text(if(quizIndex%10==9)"Yeni teste başla" else "Sonraki soru")}}
 Text("Coin kazanmak için aynı soruya tekrar basmak yetmez. Kelime öğrenmek coin vermez.",style=MaterialTheme.typography.bodySmall)
 }
 "Mağaza"->{Text("Coin mağazası",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Coin bakiyen: 🪙 $coins");Text("Coinler seri ve görevlerden kazanılır. Ücretsiz temel quizler devamlı açıktır.")
 StoreItem("Yanlışlarını tekrar testi","25 coin","Yanlış cevaplarını yeniden çöz.",coins>=25,unlocked.contains("review"),{if(unlocked.contains("review"))notice="Bu test zaten açılmış." else if(coins>=25){coins-=25;unlocked.add("review");save();notice="Yanlışlarını tekrar testi açıldı!"}else notice="Yeterli coin yok."})
 StoreItem("Özel seviye testi","50 coin","Ek seviye sınavı.",coins>=50,unlocked.contains("special"),{if(unlocked.contains("special"))notice="Bu test zaten açılmış." else if(coins>=50){coins-=50;unlocked.add("special");save();notice="Özel seviye testi açıldı!"}else notice="Yeterli coin yok."})
 StoreItem("Zor seviye sınavı","100 coin","Karışık ileri seviye sorular.",coins>=100,unlocked.contains("hard"),{if(unlocked.contains("hard"))notice="Bu sınav zaten açılmış." else if(coins>=100){coins-=100;unlocked.add("hard");save();notice="Zor seviye sınavı açıldı!"}else notice="Yeterli coin yok."})
 Text("Açılan içerikler",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(unlocked.isEmpty())Text("Henüz satın alınan test yok.") else unlocked.forEach{Text("✓ "+when(it){"review"->"Yanlışlarını tekrar testi";"special"->"Özel seviye testi";else->"Zor seviye sınavı"})}
 Divider();Text("Premium üyelik",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("Planlanan fiyat: 199,99 TL / ay");Text("Premium: reklamsız kullanım ve gelişmiş istatistikler. Gerçek ödeme için Google Play Billing ve Play Console yapılandırması gerekir; bu proje paketinde ödeme henüz etkin değildir.");OutlinedButton(onClick={notice="Premium ödeme henüz etkin değil. Önce Google Play Billing kurulumu yapılmalı."},modifier=Modifier.fillMaxWidth()){Text("Premium bilgisi")}
 }
 else->{Text("Profil",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);SmallStat("Toplam XP",xp.toString(),Modifier.fillMaxWidth());SmallStat("Coin",coins.toString(),Modifier.fillMaxWidth());SmallStat("Günlük seri","$streak gün",Modifier.fillMaxWidth());Text("Öğrenme seviyeni seç")
 listOf("A1","A2","B1","B2","C1").forEach{l->OutlinedButton(onClick={level=l;filter=l;save()},modifier=Modifier.fillMaxWidth()){Text(if(level==l)"✓ $l (seçili)" else l)}}
 Text("Favoriler",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);if(favs.isEmpty())Text("Sözlükte yıldız tuşuyla favori ekleyebilirsin.") else favs.forEach{key->words.firstOrNull{it.english==key}?.let{w->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(w.english,fontWeight=FontWeight.Bold);Text(w.turkish);TextButton(onClick={speak(w.english)}){Text("🔊 Dinle")}}}}}
 Text("Coin kazanma kuralları",fontWeight=FontWeight.Bold);Text("• 7 günlük seri: +15 coin\n• 10 soruluk testte en az %90: +5 coin (seviye/gün başına bir kez)\n• Kelime öğrenmek coin vermez.\n• Seri ve ilerleme cihazda saklanır.")
 TextButton(onClick={notice="İlerlemeyi sıfırlamak istersen uygulama verilerini Android ayarlarından temizleyebilirsin."}){Text("İlerleme hakkında")}
 }
 }
 }
 }
}

@Composable private fun SmallStat(title:String,value:String,modifier:Modifier=Modifier){Card(modifier){Column(Modifier.padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(title,style=MaterialTheme.typography.bodySmall);Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}}}
@Composable private fun StoreItem(title:String,cost:String,description:String,canBuy:Boolean,isOwned:Boolean,onBuy:()->Unit){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold);Text(description);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(if(isOwned)"Açıldı" else cost);Button(onClick=onBuy,enabled=!isOwned&&canBuy){Text(if(isOwned)"Satın alındı" else if(canBuy)"Kilidi aç" else "Yetersiz coin")}}}}}
