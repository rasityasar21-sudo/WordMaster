# WordMasterUltimate — başlangıç projesi

## İçindekiler
- İnternet istemeyen yerel sözlük: 107 kayıt (A1–C1 etiketleriyle; bu etiketler yaklaşık öğrenme seviyesidir).
- İngilizce/Türkçe arama, okunuş ipucu, örnek cümle ve Android metin okuma (TTS).
- Quiz, XP, favoriler, günlük seri ve yerel ilerleme kaydı.
- Coin yalnızca 7 günlük seri ve günlük/ seviyelik quiz başarısı gibi görevlerden verilir; kelime öğrenmek coin kazandırmaz.
- Coin mağazasında özel test kilitlerini açma.
- Premium ekranında 199,99 TL/ay planı gösterilir.

## Önemli sınırlamalar
- Bu paket kaynak koddur, APK değildir. Bu ortamda Android SDK/Gradle ile derleme testi yapılmadı. Android Studio'da açıp Gradle Sync ve Run ile kontrol et.
- Sözlükte şu an 107 giriş vardır; milyonlarca kayıt değildir. Daha büyük çevrimdışı veri tabanı için açık veri kaynağını indirip lisansını kontrol ederek `dictionary.json` dosyasına dönüştürmek gerekir.
- Premium ödeme gerçek tahsilat yapmaz. Google Play Billing, Play Console ürün tanımı, lisans/test hesabı ve satın alma doğrulaması henüz kurulmadı.
- Coin mağazası uygulama içi sanal kilit açmadır; gerçek para tahsil etmez.

## Android Studio
1. ZIP'i çıkar.
2. Android Studio → File → Open. `settings.gradle.kts` dosyasının bulunduğu `WordMasterUltimate_Full` klasörünü seç.
3. Gradle Sync tamamlanmasını bekle. Hata olursa Build Output ekranının görüntüsünü paylaş.
4. Run ile cihaz/emülatörde dene.
